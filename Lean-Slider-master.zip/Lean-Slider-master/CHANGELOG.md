# Lean Slider Changelog

Version 1.0.1 - 2014.10.02
--------------------------
 * [New] Added bower.json
 * [Changed] Made default plugin settings publicly accessible

Version 1.0.0 - 2012.10.23
--------------------------
 * Initial release
