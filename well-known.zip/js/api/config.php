<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'Xsuf5Rn0tvEjGrNKzM8GdW1qV');
    define('CONSUMER_SECRET', 'hV0OWDuZwP1yEVkBqjCHYb3iAoyY10pFn3T5f6TKKO879KrGs1');

    // User Access Token
    define('ACCESS_TOKEN', '3076358264-HKEF03oUNgsbJigCQ1o426XRsJNCXF25u48phHB');
    define('ACCESS_SECRET', 'ymFfH2RajROV8MfFo0giAE3ApbNn3akz67ktKhKDhZtZP');
    
    // Cache Settings
    define('CACHE_ENABLED', false);
    define('CACHE_LIFETIME', 3600); // in seconds
    define('HASH_SALT', md5(dirname(__FILE__)));