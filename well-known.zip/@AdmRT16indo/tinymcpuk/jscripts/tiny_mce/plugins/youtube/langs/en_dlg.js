tinyMCE.addI18n('en.youtube_dlg',{
    title: 'Insert/edit youtube video',
    url_field: 'YouTube video url or code:'
});
